(function(){
'use strict';

const FAQ=[
  {keys:['register','registration','sign up','beneficiary','apply'],answer:'You can register a beneficiary from the Register page. Complete the personal details form and continue to the program selection.'},
  {keys:['program','programs','training','course'],answer:'Our programs include Folding & Sorting, Office Work, Packaging and Handcrafts.'},
  {keys:['donate','donation','give','money'],answer:'You can make a donation from the Donate page. Choose an amount and a purpose, then continue with the donation process.'},
  {keys:['service','services','folding','sorting','packaging','photocopy'],answer:'Our services include Folding, Sorting, Packaging and Photocopying. Visit the Services page for details.'},
  {keys:['shop','product','products','rug','basket','handmade'],answer:'The shop offers handmade products including woven baskets, rugs, decorative wall art and ceramic items.'},
  {keys:['contact','phone','email','address','location'],answer:'Visit the Contact page for our address, phone number, email and office information.'},
  {keys:['hello','hi','hey'],answer:'Hello! I am the Stellenbosch Work Centre support assistant. I can help with registration, programs, donations, services, the shop and contact information.'},
  {keys:['help','what can you do'],answer:'I can answer questions about registration, available programs, donations, services, shop products and contacting the Work Centre.'}
];

const routes=['home','about','services','shop','register','contact','donate','ai-support','admin','registrations','donations-admin','programs','products-admin'];
let currentRoute='';

function replyTo(message){
  const text=String(message||'').toLowerCase();
  for(const item of FAQ) if(item.keys.some(k=>text.includes(k))) return item.answer;
  return "I don't have an answer for that yet. Try asking about registration, programs, donations, services, the shop or contact details.";
}

function showRoute(route, push){
  if(!routes.includes(route)) route='home';
  currentRoute=route;
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===route));
  document.querySelectorAll('[data-route]').forEach(a=>{
    const r=a.dataset.route;
    a.classList.toggle('active',r===route);
    if(r===route) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
  });
  const adminRoutes=['admin','registrations','donations-admin','programs','products-admin'];
  document.body.classList.toggle('admin-mode',adminRoutes.includes(route));
  if(push){
    const hash='#'+route;
    if(location.hash!==hash) history.pushState({route},'',hash);
  }
  document.getElementById('mainNav')?.classList.remove('open');
  document.getElementById('menuToggle')?.setAttribute('aria-expanded','false');
  window.scrollTo({top:0,behavior:'auto'});
}

function routeFromHash(){
  const raw=location.hash.replace(/^#/,'').trim();
  return raw||'home';
}

function addMessage(text,type){
  const box=document.getElementById('chatMessages');
  if(!box) return;
  const row=document.createElement('div');
  row.className='chat-message '+type;
  const bubble=document.createElement('div');
  bubble.className='bubble';
  bubble.textContent=text;
  row.appendChild(bubble);
  box.appendChild(row);
  box.scrollTop=box.scrollHeight;
}

function sendChat(){
  const input=document.getElementById('chatInput');
  if(!input) return;
  const text=input.value.trim();
  if(!text) return;
  addMessage(text,'user');
  input.value='';
  window.setTimeout(()=>addMessage(replyTo(text),'bot'),250);
  input.focus();
}

function setStatus(id,text){
  const el=document.getElementById(id);
  if(el) el.textContent=text;
}

document.addEventListener('DOMContentLoaded',function(){
  // One delegated navigation handler prevents duplicate listeners and broken page links.
  document.addEventListener('click',function(e){
    const routeLink=e.target.closest('[data-route]');
    if(routeLink){
      e.preventDefault();
      showRoute(routeLink.dataset.route,true);
      return;
    }

    const amount=e.target.closest('[data-amount]');
    if(amount){
      document.querySelectorAll('[data-amount]').forEach(x=>x.classList.remove('active'));
      amount.classList.add('active');
      const total=document.getElementById('donationTotal');
      if(total) total.textContent='R'+amount.dataset.amount;
      return;
    }

    const purpose=e.target.closest('[data-purpose]');
    if(purpose){
      document.querySelectorAll('[data-purpose]').forEach(x=>x.classList.remove('active'));
      purpose.classList.add('active');
      return;
    }

    const question=e.target.closest('[data-question]');
    if(question){
      const input=document.getElementById('chatInput');
      if(input){input.value=question.dataset.question;sendChat();}
      return;
    }

    const add=e.target.closest('[data-add]');
    if(add){
      const old=add.textContent;
      add.textContent='✓';
      add.setAttribute('aria-label',add.dataset.add+' added to cart');
      window.setTimeout(()=>add.textContent=old,1000);
      return;
    }
  });

  document.getElementById('menuToggle')?.addEventListener('click',function(){
    const nav=document.getElementById('mainNav');
    const open=nav.classList.toggle('open');
    this.setAttribute('aria-expanded',String(open));
  });

  document.getElementById('chatForm')?.addEventListener('submit',function(e){e.preventDefault();sendChat();});

  document.getElementById('registerForm')?.addEventListener('submit',function(e){
    e.preventDefault();
    if(!this.checkValidity()){this.reportValidity();return;}
    setStatus('registerMessage','Details accepted. The next step is program selection.');
  });

  document.getElementById('contactForm')?.addEventListener('submit',function(e){
    e.preventDefault();
    if(!this.checkValidity()){this.reportValidity();return;}
    setStatus('contactMessageStatus','Thank you. Your message has been prepared for submission.');
    this.reset();
  });

  document.getElementById('donationForm')?.addEventListener('submit',function(e){
    e.preventDefault();
    const amount=document.querySelector('[data-amount].active')?.dataset.amount||'100';
    const purpose=document.querySelector('[data-purpose].active')?.dataset.purpose||'Training Programs';
    const monthly=document.getElementById('monthlyDonation')?.checked?' monthly':'';
    setStatus('donationMessage','Donation selection saved: R'+amount+' for '+purpose+(monthly?' (monthly).':'.'));
  });

  window.addEventListener('popstate',()=>showRoute(routeFromHash(),false));
  window.addEventListener('hashchange',()=>showRoute(routeFromHash(),false));
  showRoute(routeFromHash(),false);
});
})();